# Extension classes stubs

This directory exists to document classes defined by the `cassandra.so` and
`cassandra.dll` extension in plain PHP. None of the method bodies are actually
provided, but the interfaces and documentation should be complete and match what
is exposed in the extension.
